# JedSaves — Your Money. Your Savings.

JedSaves is an offline-first mobile money fee calculator for Uganda, styled in professional green and white.

## Included
- Withdrawal and sending calculators for Airtel Money and MTN MoMo.
- Search for a low-cost transaction combination up to UGX 5,000,000.
- Optional 0.5% withdrawal-tax estimate.
- Editable local tariff tables saved on the device.
- Responsive web app/PWA in `www/`.
- Android Studio WebView project in `android/`.
- The two tariff reference images used for initial configuration.

## Important tariff note
The first Airtel tariff image supplies fixed reference charges. The second MTN & Airtel image contains approximate ranges; the app uses midpoint estimates for MTN and allows tariff editing. The 0.5% withdrawal tax is a user-toggleable estimate. Provider fees/taxes can change, so verify charges shown on the phone before confirming. This is a fee estimator, not an official Airtel or MTN product.

## Try the app
Open `www/index.html` in a modern browser. For PWA installation/offline caching, serve the `www` folder over localhost or HTTPS and choose “Install app” / “Add to Home screen” in the browser. The calculator itself is local and does not require an account.

## Build the Android APK
The Android project source is in `android/`. To build an APK:
1. Install Android Studio and an Android SDK (API 35 or compatible).
2. Open the `android` folder as an existing project.
3. Let Gradle sync and install any requested SDK components.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK path, usually `android/app/build/outputs/apk/debug/app-debug.apk`.

This delivery contains the complete project source but not a prebuilt APK because the build environment used to prepare it did not have the Android SDK or Gradle installed.

## Tariff editing format
In Tariff settings, each line is `maximum amount,fee`, for example `250000,4400`. Keep each maximum increasing. Use a sufficiently high maximum for the final row.
